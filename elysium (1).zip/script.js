const editor = document.getElementById('editor');
let savedRange = null;

function format(command) {
  if (["h1", "h2", "h3"].includes(command)) {
    document.execCommand("formatBlock", false, command);
  } else if (command === "ul") {
    document.execCommand("insertUnorderedList");
  } else if (command === "ol") {
    document.execCommand("insertOrderedList");
  }
}

function align(direction) {
  document.execCommand('justify' + direction);
}

function undoAction() {
  document.execCommand('undo');
}

function redoAction() {
  document.execCommand('redo');
}

function addButton() {
  const label = prompt("Texte du bouton :");
  const url = prompt("Lien du bouton :");
  if (label && url) {
    const btn = `<a href="${url}" target="_blank" style="display:inline-block; padding:10px 15px; background:#FFD700; color:#000; border-radius:5px; text-decoration:none;">${label}</a>`;
    insertAtCursor(btn);
  }
}

function triggerMedia(type) {
  saveCursor();
  document.getElementById(type + 'Input').click();
}

function handleFileSelect(event, type) {
  const file = event.target.files[0];
  if (!file) return;
  
  const url = URL.createObjectURL(file);
  let html = '';
  if (type === 'image' || type === 'gif') {
    html = `<img src="${url}" style="max-width:100%;" />`;
  } else if (type === 'video') {
    html = `<video controls src="${url}" style="max-width:100%;"></video>`;
  } else if (type === 'audio') {
    html = `<audio controls src="${url}"></audio>`;
  }
  
  restoreCursor();
  insertAtCursor(html);
  event.target.value = '';
}

function showCodeInput() {
  document.getElementById('codeModal').classList.add('show');
}

function closeCodeModal() {
  document.getElementById('codeModal').classList.remove('show');
}

function insertCode() {
  const code = document.getElementById('codeInput').value;
  const safeCode = escapeHTML(code);
  insertAtCursor(`<pre><code class='language-html'>${safeCode}</code></pre>`);
  Prism.highlightAll();
  closeCodeModal();
}

function previewPage() {
  document.getElementById('previewContent').innerHTML = editor.innerHTML;
  document.getElementById('previewModal').classList.add('show');
}

function closePreviewModal() {
  document.getElementById('previewModal').classList.remove('show');
}

function sharePage() {
  const blob = new Blob([editor.innerHTML], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  prompt("Voici le lien local à partager :", url);
}

function saveCursor() {
  const sel = window.getSelection();
  if (sel.rangeCount > 0) savedRange = sel.getRangeAt(0);
}

function restoreCursor() {
  if (savedRange) {
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(savedRange);
  }
}

function insertAtCursor(html) {
  document.execCommand('insertHTML', false, html);
}

function escapeHTML(str) {
  return str.replace(/[&<>'"]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[tag]));
}
